---
layout: post
title: 外语社区中不错的blog们
subtitle: /kk
tags: 杂项
---

[fajne zadania](https://fajnezadania.wordpress.com/) 作者是Paweł Gawrychowski，波兰语。高强度更新到2015年。

[Algorithms Weekly by Petr Mitrichev](https://petr-mitrichev.blogspot.com/) 作者是Petr，英语。高强度更新到2020年。

[min-25.hatenablog.com on web.archive.org](http://web.archive.org/web/*/https://min-25.hatenablog.com/*) 作者是Min_25，日语。由于忘了什么原因他关闭了这个blog，但是一部分内容可以在web.archive.org找到。

