---
layout: post
title: 讲稿索引
subtitle: /hanx
tags: 杂项
show: true
---

你去github上也能看到，但是可能比较困难，所以还是挂一个。

[微积分和组合计数](/slides/2021-10-09-math-homework.html)。用于数学作业。

[扫描线方向和dp转移结构](/slides/2022-01-06-sweepline-direction.html)，忘了有没有使用过。

[数论入门](/slides/2022-07-12-simple-number-theory.html)，于2022暑假中忘了哪天使用。

[生成函数入门](/slides/2022-07-12-simple-gf.html)，于2022-10-04使用。

[图论杂题选讲](/slides/2022-10-06-graph-theory.html)，于2022-10-06使用。汪娟锐评我说这么多牛逼题3h讲完太浪费了!

[网络流相关问题选讲](/slides/2023-04-08-flow.html)，于2023-04-08使用。包括模拟费用流，但是我并没有自信说讲的足够清楚。

