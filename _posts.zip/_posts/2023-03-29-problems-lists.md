---
layout: post
title: 我挑选的经典题题单
subtitle: /kk
tags: 题单
show: true
---

可能不会经常更新。

-----

容斥

xxi open cup gp of tokyo H. Harsh Comments

agc041 F. Histogram Rooks ($O(n^2)$)

氪金手游

排列 (https://www.zhihu.com/question/393998538) 草，这个怎么没了?就是下面那个题$m=1$的case。

sd省队胡策21 qwaszx 顺子

求有多少个长$n$的排列不包含长$m$的连续段。$n,m\leq 5\times 10^6$，膜$10^9+7$。solution https://www.luogu.com.cn/blog/qwaszx/post-20210620-xing-dui-hu-ce-qwaszx-ti-xie 。

ur19 通用测评号

zjoi2016 小星星

ctt2014 主旋律

icpc21 asia nanjing/xxii open cup gp of nanjing K. Ancient Magic Circle in Teyvat

joi final 2018 E. 毒蛇越狱 available on loj。

hdu多校2016 D1 G. Rigid Frameworks

xix open cup gp of zhejiang G. Good Game

xix open cup gp of poland L. Lines

xx open cup gp of warsaw I. Infernape

noi online 22 提高组 C. 如何正确地排序

sdoi2022 多边形

ahoi2022 山河重整

洛谷7275 计树

loj6728 u群把妹王

gdkoi23 D1 C. 异或图 available on qoj。

agc058 D. Yet Another ABC String

open cup题可以看 https://codeforces.com/blog/entry/84466 。