---
layout: post
title: Hello World!
subtitle: ShanLunjiaJian's new blog!
show: true
---

## Hello world!

在github上搞了个blog，之前的文章哪天有兴趣就搬一下，然后以后写blog就是同步发表或者只发在这边了。

upd: 选了几篇比较有代表性的，先搬过来。发布时间都是按当时发的时间写的，所以看到有比这篇更老的是正常现象（

从洛谷blog搬过来的文章，有些洛谷图床上的图片是显示不了的，这个问题我闲着没事会解决一下。