---
layout: post
title: 关于如何成为vtuber
subtitle: /oh
tags: 杂项
---

哪天出个道。咍咍

-----

talking head anime是不错的。

主要问题是用什么代替ifacialmocap。它的pc端是免费的，android上可以用meowface来搞定。

然后经过混乱邪恶的多次尝试就连上了。很赢。

![img](/img/2023-02-03-how-to-be-a-vtuber/img.png)

你也看到我的fps只有4。这样是出不了道的。等我有钱了买个tesla玩玩。现在手里是3050，比较的拉!

需要注意的一个问题是，ifacialmocap的pc端disconnect写挂了，也就是说每次启动只能connect一次，reconnect不可靠，需要重启。meowface不能后台运行也比较难受。